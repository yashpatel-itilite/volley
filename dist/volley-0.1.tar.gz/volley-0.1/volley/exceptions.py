class ValidationError(ValueError):
	pass
